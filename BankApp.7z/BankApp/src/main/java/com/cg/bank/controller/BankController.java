package com.cg.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bank.bean.Bank;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.IBankService;


@CrossOrigin(origins="http://localhost:4200")
@RestController

public class BankController {

	@Autowired
	IBankService bankService;
	
	@RequestMapping(value="/bank",method=RequestMethod.POST)
	public List<Bank> addBank(@RequestBody Bank bank) throws BankException{
		return bankService.addBank(bank);
	}
	@RequestMapping("/bank")
	public List<Bank> getBankDetails() throws BankException{
		return bankService.getAllBankDetials();
	}
	
	@RequestMapping(value="/showbalance/{accountnum}",method=RequestMethod.GET)
    public int getBankDetailsByAccountnum(@PathVariable int accountnum) throws BankException{
        return bankService.showBalance(accountnum);
    }
	
	@RequestMapping(value="/creditbank/{accountnum}/{amount}",method=RequestMethod.PUT)
	public Bank depositMoney(@PathVariable Integer accountnum,@PathVariable Integer amount) throws BankException{
		return bankService.depositMoney(accountnum, amount);
	}
	
	@RequestMapping(value="/withdrawbank/{accountnum}/{amount}",method=RequestMethod.PUT)
	public Bank withdrawMoney(@PathVariable Integer accountnum,@PathVariable Integer amount) throws BankException{
		return bankService.withdrawMoney(accountnum, amount);
	}
	
	@RequestMapping(value="/fundtransfer/{accountnum1}/{accountnum2}/{amount}",method=RequestMethod.PUT)
	public Bank fundTransfer(@PathVariable Integer accountnum1,@PathVariable Integer accountnum2,@PathVariable Integer amount) throws BankException{
		return bankService.fundTransfer(accountnum1,accountnum2, amount);
	}
	
	@RequestMapping(value="/login/username/password",method=RequestMethod.PUT)
	public List getCustomerByLoginDetails(@PathVariable String username,@PathVariable String password) throws BankException{
		return bankService.getCustomerByLoginDetails(username,password);
	}
	
}
