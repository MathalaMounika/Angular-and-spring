package com.cg.bank.dao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.bank.bean.Bank;
import com.cg.bank.exception.BankException;

	@Repository
	public interface BankDao extends JpaRepository<Bank, Integer>{

		//@Query("from Bank where accountnum=:accountnum")
		//int getBankDetailsByAccountnum(int accountnum);
		
		@Query("from Bank where username=:user and password=:pass")
			List<Bank> getDetails(@Param("user") String username,@Param("pass")String password );
		
	}


